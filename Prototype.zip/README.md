### פרויקט מאגר חיפוש שאלות
# pip install pillow
###### https://www.tutorialspoint.com/python/python_gui_programming.htm
# pip install docx
# pip install python-docx
# pip install PyPDF2
